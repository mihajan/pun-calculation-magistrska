# PUN Clearing — Savelli et al. (2017) MILP Implementation

Implementation of the MILP market clearing model for the Italian day-ahead
electricity market with Uniform Purchase Price (PUN) and zonal selling prices.

**Reference:** Savelli, Giannitrapani, Paoletti, Vicino — "An Optimization Model
for the Electricity Market Clearing Problem with Uniform Purchase Price and
Zonal Selling Prices," IEEE Trans. Power Syst., 2017.

## Project Structure

```
pun_clearing/
├── conf/
│   └── options.py          # Solver config, big-M values, binary expansion params
├── model/
│   ├── data_classes.py     # Bid, PunOrder, Zone, Line — plain data containers
│   ├── orders_book.py      # OrdersBook — collects all bids for one hour
│   └── pun_model.py        # THE CORE: builds and solves the Savelli 2017 MILP
├── dataio/
│   └── gme_importer.py     # Reads GME XML files into data_classes objects
├── run_hourly.py           # Entry point: load data → build model → solve → report
└── README.md
```

## How the code maps to the paper

The MILP in Appendix A of Savelli 2017 has equations (34)–(66).
Each constraint in `pun_model.py` is labeled with the corresponding
equation number. The pipeline is:

1. **Bilevel model** (Section II-A): upper level handles UPP rule + binary
   variables; lower level is an LP that clears the market.
2. **Single-level equivalent** (Section II-B): replace lower level LP with
   strong duality + primal feasibility + dual feasibility.
3. **MILP linearization** (Section II-C): linearize all bilinear terms
   (binary × continuous via big-M, binary expansion for UPP definition).

Since we have NO block orders, each hour is independent → we solve 24
separate MILPs per day instead of one coupled 24-hour problem.

## Key simplifications vs. openDAM (Savelli et al. 2018)

- No block orders (no `rp`, `ubp`, `vphibMax`, `vphibMin`)
- No `u^w_tk` / `u^d_tk` split — only `u^e_k` for at-the-money orders
- No market-split detection (`uf` variables) — can be added later
- No `κ_t` tolerance — exact PUN definition (eq. 1 of the paper)
- Hourly independence — 24 small MILPs instead of 1 large one
