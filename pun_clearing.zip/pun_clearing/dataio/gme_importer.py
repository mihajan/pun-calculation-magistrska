"""
GME data importer for the Italian day-ahead market (MGP).

Reads XML files downloaded from the GME website:
  https://www.mercatoelettrico.org/en-us/Home/Results/Electricity/MGP/Download/Download

Required files for a given date YYYYMMDD (place all in one folder):
  1. 20100504MGPOffertePubbliche.xml (or inside a .zip)  — all bid/offer orders
  2. 20100504MGPLimitiTransito.xml (or inside a .zip)    — transmission limits
  3. 20100504MGPPrezzi.xml (or inside a .zip)             — published prices (validation)

Optional:
  4. 20100504MGPTransiti.xml  — actual flows (for validation, not used by model)

The importer converts these into HourlyData objects (one per hour),
which can be fed directly to pun_model.build_and_solve().

Usage:
    from pun_clearing.dataio.gme_importer import GMEImporter
    importer = GMEImporter(path='./gme_data', date='20100504')
    hourly_problems = importer.get_hourly_data()  # dict {hour: HourlyData}
    real_prices = importer.get_real_prices()       # for validation
"""

import os
import glob
import zipfile
import logging
from collections import defaultdict

from lxml import etree

from pun_clearing.model.data_classes import (
    SupplyBid, DemandBid, PunBid, Zone, Line, HourlyData
)
from pun_clearing.conf import options

logger = logging.getLogger(__name__)

PUN_ZONE_NAMES = set(options.PUN_ZONES)


def _find_xml(path, date, pattern):
    """Find an XML file matching a pattern, extracting from zip if needed."""
    # Try direct XML first
    xml_name = f"{date}{pattern}.xml"
    xml_path = os.path.join(path, xml_name)
    if os.path.exists(xml_path):
        return xml_path

    # Search in zip files
    for zf_path in glob.glob(os.path.join(path, "*.zip")):
        try:
            with zipfile.ZipFile(zf_path, 'r') as zf:
                for name in zf.namelist():
                    if pattern in name and name.endswith('.xml'):
                        zf.extract(name, path)
                        return os.path.join(path, name)
        except zipfile.BadZipFile:
            continue

    return None


class GMEImporter:
    def __init__(self, path, date):
        self.path = path
        self.date = date
        self._zones = {}
        self._zone_id_counter = 0
        self._lines = []
        self._supply = defaultdict(list)
        self._demand = defaultdict(list)
        self._pun = defaultdict(list)
        self._real_prices = {}
        self._all_periods = set()
        self._bid_id_counter = 0

        self._read_network()
        self._read_bids()
        self._read_prices()

        logger.info(f"Loaded data for {date}: {len(self._all_periods)} hours, "
                    f"{len(self._zones)} zones, {len(self._lines)} lines")

    def _next_bid_id(self):
        self._bid_id_counter += 1
        return self._bid_id_counter

    def _get_zone_id(self, zone_name):
        if zone_name not in self._zones:
            self._zone_id_counter += 1
            self._zones[zone_name] = self._zone_id_counter
        return self._zones[zone_name]

    def _read_network(self):
        xml_path = _find_xml(self.path, self.date, 'MGPLimitiTransito')
        if xml_path is None:
            raise FileNotFoundError(
                f"Cannot find MGPLimitiTransito XML for {self.date} in {self.path}")

        tree = etree.parse(xml_path)
        raw_limits = defaultdict(dict)

        for el in tree.xpath('/NewDataSet/LimitiTransito'):
            period = int(el.find('Ora').text)
            self._all_periods.add(period)
            from_zone = el.find('Da').text
            to_zone = el.find('A').text
            limit = float(el.find('Limite').text.replace(',', '.'))
            self._get_zone_id(from_zone)
            self._get_zone_id(to_zone)
            raw_limits[(from_zone, to_zone)][period] = limit

        seen_pairs = set()
        line_id = 0
        for (from_z, to_z) in raw_limits:
            pair = tuple(sorted([from_z, to_z]))
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            fwd_caps = raw_limits.get((pair[0], pair[1]), {})
            rev_caps = raw_limits.get((pair[1], pair[0]), {})
            line_id += 1
            self._lines.append(Line(
                line_id=line_id,
                from_zone_id=self._get_zone_id(pair[0]),
                to_zone_id=self._get_zone_id(pair[1]),
                capacity=fwd_caps,
                capacity_rev=rev_caps,
            ))

        logger.info(f"Read {len(self._lines)} transmission lines")

    def _read_bids(self):
        xml_path = _find_xml(self.path, self.date, 'MGPOffertePubbliche')
        if xml_path is None:
            raise FileNotFoundError(
                f"Cannot find MGPOffertePubbliche XML for {self.date} in {self.path}")

        tree = etree.parse(xml_path)
        n_skip = n_pun = n_demand = n_supply = 0

        for el in tree.xpath('/NewDataSet/OfferteOperatori'):
            status_el = el.find('STATUS_CD')
            if status_el is None:
                continue
            status = status_el.text
            if status in ('INC', 'REP', 'REV'):
                n_skip += 1
                continue

            purpose = el.find('PURPOSE_CD').text
            period = int(el.find('INTERVAL_NO').text)
            price = float(el.find('ENERGY_PRICE_NO').text)
            volume = float(el.find('ADJ_QUANTITY_NO').text)
            zone_name = el.find('ZONE_CD').text
            merit_order_el = el.find('MERIT_ORDER_NO')
            merit_order = int(merit_order_el.text) if merit_order_el is not None else 0
            unit_el = el.find('UNIT_REFERENCE_NO')
            unit_name = unit_el.text if unit_el is not None else ''

            self._all_periods.add(period)
            zone_id = self._get_zone_id(zone_name)

            if purpose == 'BID':
                if price == 0.0 and status == 'ACC':
                    price = options.MAX_PRICE
                is_pun_zone = zone_name in PUN_ZONE_NAMES
                is_pumping = unit_name.startswith('UP_') if unit_name else False

                if is_pun_zone and not is_pumping:
                    self._pun[period].append(PunBid(
                        bid_id=self._next_bid_id(),
                        zone_id=zone_id, period=period,
                        volume=volume, price=price,
                        merit_order=merit_order,
                    ))
                    n_pun += 1
                else:
                    self._demand[period].append(DemandBid(
                        bid_id=self._next_bid_id(),
                        zone_id=zone_id, period=period,
                        volume=volume, price=price,
                    ))
                    n_demand += 1

            elif purpose == 'OFF':
                self._supply[period].append(SupplyBid(
                    bid_id=self._next_bid_id(),
                    zone_id=zone_id, period=period,
                    volume=volume, price=price,
                ))
                n_supply += 1

        logger.info(f"Read {n_pun + n_demand + n_supply} active orders "
                    f"({n_pun} PUN, {n_demand} non-PUN demand, {n_supply} supply), "
                    f"skipped {n_skip}")

    def _read_prices(self):
        xml_path = _find_xml(self.path, self.date, 'MGPPrezzi')
        if xml_path is None:
            logger.warning("Cannot find MGPPrezzi XML — skipping price validation")
            return

        tree = etree.parse(xml_path)
        for el in tree.xpath('/NewDataSet/Prezzi'):
            period = int(el.find('Ora').text)
            self._real_prices[period] = {}
            pun_el = el.find('PUN')
            if pun_el is not None and pun_el.text:
                self._real_prices[period]['PUN'] = float(pun_el.text.replace(',', '.'))
            for zone_name in self._zones:
                zone_el = el.find(zone_name)
                if zone_el is not None and zone_el.text:
                    self._real_prices[period][zone_name] = float(
                        zone_el.text.replace(',', '.'))

        logger.info(f"Read published prices for {len(self._real_prices)} hours")

    def get_hourly_data(self):
        zone_objects = {}
        for name, z_id in self._zones.items():
            zone_objects[z_id] = Zone(
                zone_id=z_id, name=name, is_pun=(name in PUN_ZONE_NAMES))
        result = {}
        for period in sorted(self._all_periods):
            result[period] = HourlyData(
                period=period, zones=zone_objects, lines=self._lines,
                supply_bids=self._supply.get(period, []),
                demand_bids=self._demand.get(period, []),
                pun_bids=self._pun.get(period, []),
            )
        return result

    def get_real_prices(self):
        return self._real_prices

    def get_zone_name_to_id(self):
        return dict(self._zones)
