"""
Minimal test: run the PUN clearing MILP on synthetic data.

This creates a tiny 2-zone market with a handful of bids and solves it.
Purpose: verify the model builds and solves correctly before tackling
real GME data with 20,000+ orders.

Market setup:
  - Zone 1 (NORD): PUN zone
  - Zone 2 (XFRA): non-PUN zone (foreign)
  - One transmission line between them with 50 MWh capacity
  - Hour 1 only

Expected behavior:
  - PUN bids with price > π are fully executed (u^g_k = 1)
  - PUN bids with price = π are partially executed (u^e_k = 1)
  - PUN bids with price < π are rejected
  - Zonal prices are the shadow prices of the power balance constraints
  - π is the demand-weighted average of zonal prices over PUN zones
"""

import logging
import sys
import os

# Add parent directory to path so imports work when run directly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pun_clearing.model.data_classes import (
    SupplyBid, DemandBid, PunBid, Zone, Line, HourlyData
)
from pun_clearing.model.pun_model import build_and_solve

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')


def create_test_data():
    """Build a small synthetic market for testing.

    Zone 1 (NORD) — PUN zone:
      Supply:  3 offers at prices 10, 20, 30 €/MWh, 100 MWh each
      PUN demand: 4 bids at prices 50, 35, 25, 15 €/MWh, 80 MWh each

    Zone 2 (XFRA) — non-PUN zone:
      Supply:  1 offer at 5 €/MWh, 50 MWh
      Demand:  1 bid at 40 €/MWh, 30 MWh

    Line: NORD→XFRA capacity 50 MWh each direction.
    """

    # --- Zones ---
    zones = {
        1: Zone(zone_id=1, name="NORD", is_pun=True),
        2: Zone(zone_id=2, name="XFRA", is_pun=False),
    }

    # --- Lines ---
    # capacity and capacity_rev are dicts {period: MWh}
    lines = [
        Line(line_id=1, from_zone_id=1, to_zone_id=2,
             capacity={1: 50.0}, capacity_rev={1: 50.0})
    ]

    # --- Supply bids in NORD (zone 1) ---
    supply_bids = [
        SupplyBid(bid_id=1, zone_id=1, period=1, volume=100.0, price=10.0),
        SupplyBid(bid_id=2, zone_id=1, period=1, volume=100.0, price=20.0),
        SupplyBid(bid_id=3, zone_id=1, period=1, volume=100.0, price=30.0),
    ]

    # --- Supply bid in XFRA (zone 2) ---
    supply_bids.append(
        SupplyBid(bid_id=4, zone_id=2, period=1, volume=50.0, price=5.0)
    )

    # --- Non-PUN demand in XFRA (zone 2) ---
    demand_bids = [
        DemandBid(bid_id=5, zone_id=2, period=1, volume=30.0, price=40.0),
    ]

    # --- PUN bids in NORD (zone 1) ---
    # Merit order matches price ranking: higher price → lower merit order
    pun_bids = [
        PunBid(bid_id=6, zone_id=1, period=1, volume=80.0, price=50.0, merit_order=1),
        PunBid(bid_id=7, zone_id=1, period=1, volume=80.0, price=35.0, merit_order=2),
        PunBid(bid_id=8, zone_id=1, period=1, volume=80.0, price=25.0, merit_order=3),
        PunBid(bid_id=9, zone_id=1, period=1, volume=80.0, price=15.0, merit_order=4),
    ]

    return HourlyData(
        period=1,
        zones=zones,
        lines=lines,
        supply_bids=supply_bids,
        demand_bids=demand_bids,
        pun_bids=pun_bids,
    )


def print_results(data):
    """Print a human-readable summary of the clearing results."""

    print("\n" + "=" * 60)
    print(f"  RESULTS — Hour {data.period}")
    print("=" * 60)

    print(f"\n  PUN (π) = {data.pun_price:.6f} €/MWh")
    print(f"  Social welfare = {data.social_welfare:.2f} €")

    print("\n  Zonal prices:")
    for z_id, price in sorted(data.zonal_prices.items()):
        name = data.zones[z_id].name
        print(f"    Zone {name} (id={z_id}): ζ = {price:.6f} €/MWh")

    print("\n  PUN bids (UPP consumers):")
    print(f"    {'ID':>4}  {'Price':>8}  {'Volume':>8}  {'Accepted':>10}  {'Status'}")
    print(f"    {'—'*4}  {'—'*8}  {'—'*8}  {'—'*10}  {'—'*12}")
    for bid in data.pun_bids:
        executed = bid.acceptance * bid.volume
        if bid.acceptance > 0.999:
            status = "ITM (full)"
        elif bid.acceptance > 0.001:
            status = "ATM (partial)"
        else:
            status = "OTM (rejected)"
        print(f"    {bid.bid_id:>4}  {bid.price:>8.2f}  {bid.volume:>8.1f}  "
              f"{executed:>10.3f}  {status}")

    print("\n  Supply bids:")
    print(f"    {'ID':>4}  {'Zone':>6}  {'Price':>8}  {'Volume':>8}  {'Accepted':>10}")
    print(f"    {'—'*4}  {'—'*6}  {'—'*8}  {'—'*8}  {'—'*10}")
    for bid in data.supply_bids:
        executed = bid.acceptance * bid.volume
        zone_name = data.zones[bid.zone_id].name
        print(f"    {bid.bid_id:>4}  {zone_name:>6}  {bid.price:>8.2f}  "
              f"{bid.volume:>8.1f}  {executed:>10.3f}")

    print("\n  Non-UPP demand bids:")
    print(f"    {'ID':>4}  {'Zone':>6}  {'Price':>8}  {'Volume':>8}  {'Accepted':>10}")
    print(f"    {'—'*4}  {'—'*6}  {'—'*8}  {'—'*8}  {'—'*10}")
    for bid in data.demand_bids:
        executed = bid.acceptance * bid.volume
        zone_name = data.zones[bid.zone_id].name
        print(f"    {bid.bid_id:>4}  {zone_name:>6}  {bid.price:>8.2f}  "
              f"{bid.volume:>8.1f}  {executed:>10.3f}")

    # Verify PUN definition: π · Σd^π_k = Σ_i ζ_i · Σ_{k∈i} d^π_k
    total_pun_demand = 0.0
    weighted_zonal = 0.0
    for bid in data.pun_bids:
        executed = bid.acceptance * bid.volume
        total_pun_demand += executed
        weighted_zonal += data.zonal_prices[bid.zone_id] * executed

    if total_pun_demand > 0:
        implied_pun = weighted_zonal / total_pun_demand
        print(f"\n  Verification: π·Σd = {data.pun_price * total_pun_demand:.4f}, "
              f"Σζ·d = {weighted_zonal:.4f}")
        print(f"  Implied PUN from weighted avg = {implied_pun:.6f} "
              f"(should equal π = {data.pun_price:.6f})")


if __name__ == "__main__":
    data = create_test_data()

    try:
        result = build_and_solve(data, solver_name='appsi_highs')
        print_results(result)
    except Exception as e:
        print(f"\nError: {e}")
        print("\nMake sure you have a solver installed. Try:")
        print("  pip install pyomo")
        print("  # And one of: cplex, gurobi, or glpk")
        print("  # For glpk: conda install -c conda-forge glpk")
        raise
